#include <stdio.h>

int main()
{
    printf("Welcome to Operating Systems\n");
    return 0;
}
