OS Practical Codes
=================

Codes reconstructed from the uploaded OS practical documents.

1-10   : OS Practical Input/Output
11-12  : Practical 3 & 4
13-14  : Practical 5
15-16  : Practical 6
17-19  : Pipes / FIFO
20-23  : Scheduling Algorithms
24     : Parent and child executing concurrently
25     : Zombie process
26     : Orphan process

Compile a normal C file:
    gcc filename.c -o filename
    ./filename

FIFO:
    gcc 17_fifo_create.c -o fifo_create
    ./fifo_create
    gcc 18_fifo_read.c -o fifo_read
    gcc 19_fifo_write.c -o fifo_write
Run fifo_read and fifo_write in separate terminals.

Unix socket:
    gcc 15_unix_server.c -o unix_server
    gcc 16_unix_client.c -o unix_client
Run ./unix_server first, then ./unix_client in another terminal.

Signal program:
    gcc 14_posix_signal.c -o posix
    ./posix
From another terminal, send signals using:
    kill -SIGINT <PID>
    kill -SIGTERM <PID>
    kill -SIGUSR1 <PID>
